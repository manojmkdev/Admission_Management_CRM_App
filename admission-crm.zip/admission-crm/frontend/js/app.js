/**
 * app.js — Full application logic
 *
 * FIXES IN THIS VERSION:
 * 1. Allocate Seat — refreshes modal after action so button disables correctly
 * 2. Document Status Flow — PENDING → SUBMITTED → VERIFIED only (strict, no going back)
 * 3. Once ADMITTED — all action buttons locked
 * 4. Dashboard seat matrix — correct admitted count
 * 5. Applicant form validations:
 *    - Government mode ↔ quota compatibility enforced
 *    - DOB cannot be today or future
 *    - Qualifying marks must be 0–100
 *    - Phone must be exactly 10 digits
 */

// ─── INIT ────────────────────────────────────────────────────
const user = requireAuth();

if (user) {
    document.getElementById('navUserName').textContent = user.fullName;
    document.getElementById('navUserRole').textContent = user.role.replace(/_/g, ' ');
    document.getElementById('topbarUser').textContent = `${user.fullName} (${user.role})`;
    applyRoleBasedUI(user.role);
    setupNavigation();
    setupAllForms();
    loadDashboard();
}

function applyRoleBasedUI(role) {
    if (role === 'ADMIN') document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
    if (role === 'ADMIN' || role === 'ADMISSION_OFFICER') document.querySelectorAll('.officer-nav').forEach(el => el.classList.remove('hidden'));
}

function setupNavigation() {
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
        item.addEventListener('click', e => { e.preventDefault(); navigateTo(item.dataset.page); });
    });
}

function navigateTo(pageName) {
    document.querySelectorAll('.page').forEach(p => { p.classList.add('hidden'); p.classList.remove('active'); });
    const target = document.getElementById(`page-${pageName}`);
    if (target) { target.classList.remove('hidden'); target.classList.add('active'); }
    document.querySelectorAll('.nav-item[data-page]').forEach(item => item.classList.toggle('active', item.dataset.page === pageName));
    const titles = { 'dashboard':'Dashboard','setup-institution':'Master Setup — Institution','setup-campus':'Master Setup — Campus','setup-department':'Master Setup — Department','programs':'Programs & Seat Matrix','applicants':'All Applicants','new-applicant':'New Applicant','pending-docs':'Pending Documents','pending-fees':'Pending Fees' };
    document.getElementById('pageTitle').textContent = titles[pageName] || pageName;
    switch (pageName) {
        case 'dashboard': loadDashboard(); break;
        case 'setup-institution': loadInstitutionPage(); break;
        case 'setup-campus': loadCampusPage(); break;
        case 'setup-department': loadDepartmentPage(); break;
        case 'programs': loadProgramsPage(); break;
        case 'applicants': loadApplicants(); break;
        case 'new-applicant': loadProgramsForForm(); break;
        case 'pending-docs': loadPendingDocs(); break;
        case 'pending-fees': loadPendingFees(); break;
    }
}

// ── DASHBOARD ─────────────────────────────────────────────────
async function loadDashboard() {
    try {
        const res = await dashboardAPI.get();
        const d = res.data;
        document.getElementById('totalApplicants').textContent = d.totalApplicants;
        document.getElementById('totalAdmitted').textContent   = d.totalAdmitted;
        document.getElementById('pendingDocs').textContent     = d.pendingDocuments;
        document.getElementById('pendingFees').textContent     = d.pendingFees;
        const tbody = document.getElementById('seatMatrixBody');
        if (!d.programSummaries || d.programSummaries.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center" style="color:var(--text-light)">No programs configured yet.</td></tr>';
            return;
        }
        tbody.innerHTML = d.programSummaries.map(p => `
            <tr>
                <td><strong>${p.programName}</strong></td>
                <td>${p.departmentName}</td>
                <td>${p.totalIntake}</td>
                <td><strong>${p.totalAdmitted}</strong></td>
                <td class="${seatCss(p.totalRemaining, p.totalIntake)}">${p.totalRemaining}</td>
                <td class="${seatCss(p.kcetAvailable,1)}">${p.kcetAvailable}</td>
                <td class="${seatCss(p.comedkAvailable,1)}">${p.comedkAvailable}</td>
                <td class="${seatCss(p.managementAvailable,1)}">${p.managementAvailable}</td>
            </tr>`).join('');
    } catch (err) {
        document.getElementById('seatMatrixBody').innerHTML = `<tr><td colspan="8" class="text-center text-red">${err.message}</td></tr>`;
    }
}
function seatCss(n) { if (n === 0) return 'seats-full'; if (n <= 5) return 'seats-low'; return 'seats-ok'; }

// ── INSTITUTION ───────────────────────────────────────────────
async function loadInstitutionPage() { loadInstitutionsTable(); }
async function loadInstitutionsTable() {
    const tbody = document.getElementById('institutionsBody');
    try {
        const res = await institutionAPI.getAll();
        const list = res.data || [];
        tbody.innerHTML = list.length === 0 ? '<tr><td colspan="4" class="text-center">No institutions yet.</td></tr>'
            : list.map(i => `<tr><td><strong>${i.id}</strong></td><td>${i.name}</td><td><span class="badge badge-blue">${i.code}</span></td><td>${i.email||'—'}</td></tr>`).join('');
    } catch (err) { tbody.innerHTML = `<tr><td colspan="4" class="text-red text-center">${err.message}</td></tr>`; }
}

// ── CAMPUS ────────────────────────────────────────────────────
async function loadCampusPage() {
    await populateInstitutionSelect('campusInstSelect');
    await populateInstitutionSelect('campusFilterInst', true);
    loadCampusesTable();
}
async function loadCampusesTable() {
    const tbody = document.getElementById('campusesBody');
    const filterInstId = document.getElementById('campusFilterInst')?.value;
    try {
        const instRes = await institutionAPI.getAll();
        const institutions = instRes.data || [];
        if (!institutions.length) { tbody.innerHTML = '<tr><td colspan="4" class="text-center">No institutions. Create one first.</td></tr>'; return; }
        const toLoad = filterInstId ? institutions.filter(i => i.id == filterInstId) : institutions;
        let allRows = [];
        for (const inst of toLoad) {
            const r = await campusAPI.getByInstitution(inst.id);
            (r.data||[]).forEach(c => allRows.push({...c, institutionName: inst.name}));
        }
        tbody.innerHTML = !allRows.length ? '<tr><td colspan="4" class="text-center">No campuses yet.</td></tr>'
            : allRows.map(c => `<tr><td><strong>${c.id}</strong></td><td>${c.name}</td><td>${c.institutionName}</td><td>${c.location||'—'}</td></tr>`).join('');
    } catch (err) { tbody.innerHTML = `<tr><td colspan="4" class="text-red text-center">${err.message}</td></tr>`; }
}

// ── DEPARTMENT ────────────────────────────────────────────────
async function loadDepartmentPage() {
    await populateInstitutionSelect('deptInstSelect');
    await populateInstitutionSelect('deptFilterInst', true);
    loadDepartmentsTable();
}
async function loadCampusesForDept() {
    const instId = document.getElementById('deptInstSelect').value;
    const sel = document.getElementById('deptCampusSelect');
    sel.innerHTML = '<option value="">— Select Campus —</option>';
    if (!instId) return;
    try { const r = await campusAPI.getByInstitution(instId); (r.data||[]).forEach(c => sel.innerHTML += `<option value="${c.id}">${c.name}</option>`); } catch(e){}
}
async function loadCampusFilterForDepts() {
    const instId = document.getElementById('deptFilterInst').value;
    const sel = document.getElementById('deptFilterCampus');
    sel.innerHTML = '<option value="">All Campuses</option>';
    if (!instId) { loadDepartmentsTable(); return; }
    try { const r = await campusAPI.getByInstitution(instId); (r.data||[]).forEach(c => sel.innerHTML += `<option value="${c.id}">${c.name}</option>`); loadDepartmentsTable(); } catch(e){}
}
async function loadDepartmentsTable() {
    const tbody = document.getElementById('departmentsBody');
    const campusFilterId = document.getElementById('deptFilterCampus')?.value;
    try {
        const instRes = await institutionAPI.getAll();
        const institutions = instRes.data || [];
        if (!institutions.length) { tbody.innerHTML = '<tr><td colspan="4" class="text-center">No institutions.</td></tr>'; return; }
        let allDepts = [];
        for (const inst of institutions) {
            const cr = await campusAPI.getByInstitution(inst.id);
            for (const campus of (cr.data||[])) {
                if (campusFilterId && campus.id != campusFilterId) continue;
                const dr = await departmentAPI.getByCampus(campus.id);
                (dr.data||[]).forEach(d => allDepts.push({...d, campusName: campus.name}));
            }
        }
        tbody.innerHTML = !allDepts.length ? '<tr><td colspan="4" class="text-center">No departments yet.</td></tr>'
            : allDepts.map(d => `<tr><td><strong>${d.id}</strong></td><td>${d.name}</td><td><span class="badge badge-blue">${d.code}</span></td><td>${d.campusName}</td></tr>`).join('');
    } catch (err) { tbody.innerHTML = `<tr><td colspan="4" class="text-red text-center">${err.message}</td></tr>`; }
}

// ── PROGRAMS ──────────────────────────────────────────────────
async function loadProgramsPage() { await populateInstitutionSelect('progInstSelect'); loadPrograms(); }
async function loadCampusesForProg() {
    const instId = document.getElementById('progInstSelect').value;
    const sel = document.getElementById('progCampusSelect');
    sel.innerHTML = '<option value="">— Select Campus —</option>';
    document.getElementById('progDeptSelect').innerHTML = '<option value="">— Select Department —</option>';
    if (!instId) return;
    try { const r = await campusAPI.getByInstitution(instId); (r.data||[]).forEach(c => sel.innerHTML += `<option value="${c.id}">${c.name}</option>`); } catch(e){}
}
async function loadDepartmentsForProg() {
    const campusId = document.getElementById('progCampusSelect').value;
    const sel = document.getElementById('progDeptSelect');
    sel.innerHTML = '<option value="">— Select Department —</option>';
    if (!campusId) return;
    try { const r = await departmentAPI.getByCampus(campusId); (r.data||[]).forEach(d => sel.innerHTML += `<option value="${d.id}">${d.name} (${d.code})</option>`); } catch(e){}
}
async function loadPrograms() {
    const tbody = document.getElementById('programsBody');
    try {
        const res = await programAPI.getAll();
        const list = res.data || [];
        tbody.innerHTML = !list.length ? '<tr><td colspan="10" class="text-center">No programs yet.</td></tr>'
            : list.map(p => `<tr>
                <td><strong>${p.name}</strong></td><td><code>${p.code}</code></td><td>${p.courseType}</td>
                <td>${p.departmentName}</td><td>${p.totalIntake}</td>
                <td class="${seatCss(p.kcetAvailable)}">${p.kcetAllocated}/${p.kcetSeats}</td>
                <td class="${seatCss(p.comedkAvailable)}">${p.comedkAllocated}/${p.comedkSeats}</td>
                <td class="${seatCss(p.managementAvailable)}">${p.managementAllocated}/${p.managementSeats}</td>
                <td>${p.totalAdmitted}</td>
                <td class="${seatCss(p.totalRemaining)}"><strong>${p.totalRemaining}</strong></td>
              </tr>`).join('');
    } catch (err) { tbody.innerHTML = `<tr><td colspan="10" class="text-red text-center">${err.message}</td></tr>`; }
}
function toggleProgramForm() {
    const c = document.getElementById('programFormContainer');
    const isHidden = c.classList.contains('hidden');
    c.classList.toggle('hidden');
    if (isHidden) {
        populateInstitutionSelect('progInstSelect');
        document.getElementById('progCampusSelect').innerHTML = '<option value="">— Select Campus —</option>';
        document.getElementById('progDeptSelect').innerHTML = '<option value="">— Select Department —</option>';
    }
}
function validateSeats() {
    const total = parseInt(document.getElementById('totalIntake').value)||0;
    const kcet  = parseInt(document.getElementById('kcetSeats').value)||0;
    const comedk= parseInt(document.getElementById('comedkSeats').value)||0;
    const mgmt  = parseInt(document.getElementById('managementSeats').value)||0;
    const sum = kcet+comedk+mgmt;
    const msg = document.getElementById('seatValidationMsg');
    if (!total) { msg.textContent=''; return; }
    msg.textContent = sum===total ? `✅ ${kcet} + ${comedk} + ${mgmt} = ${total} ✓` : `❌ ${kcet} + ${comedk} + ${mgmt} = ${sum} ≠ ${total}`;
    msg.style.color = sum===total ? 'var(--success)' : 'var(--danger)';
}

// ── APPLICANTS ────────────────────────────────────────────────
async function loadApplicants() {
    const tbody = document.getElementById('applicantsBody');
    tbody.innerHTML = '<tr><td colspan="9" class="text-center">Loading...</td></tr>';
    try {
        const res = await applicantAPI.getAll();
        const list = res.data || [];
        tbody.innerHTML = !list.length ? '<tr><td colspan="9" class="text-center">No applicants yet.</td></tr>'
            : list.map(a => `<tr>
                <td>#${a.id}</td>
                <td><strong>${a.firstName} ${a.lastName}</strong></td>
                <td>${a.email}</td><td>${a.programName}</td>
                <td><span class="badge badge-blue">${a.quotaType}</span></td>
                <td>${statusBadge(a.status)}</td>
                <td>${docBadge(a.documentStatus)}</td>
                <td>${feeBadge(a.feeStatus)}</td>
                <td>
                  ${a.status === 'ADMITTED'
                    ? `<span class="badge badge-green">🎓 Admitted</span><br><small style="color:var(--success);font-weight:700">${a.admissionNumber||''}</small>`
                    : `<button class="btn btn-sm btn-primary" onclick="openApplicantActions(${a.id})">Actions</button>`}
                </td>
              </tr>`).join('');
    } catch (err) { tbody.innerHTML = `<tr><td colspan="9" class="text-red text-center">${err.message}</td></tr>`; }
}

async function loadProgramsForForm() {
    const sel = document.getElementById('programSelect');
    if (!sel) return;
    try {
        const res = await programAPI.getAll();
        sel.innerHTML = '<option value="">— Select Program —</option>';
        (res.data||[]).forEach(p => sel.innerHTML += `<option value="${p.id}">${p.name} (${p.courseType}) — ${p.departmentName} | KCET:${p.kcetAvailable} COMEDK:${p.comedkAvailable} Mgmt:${p.managementAvailable}</option>`);
    } catch(e){}
}

// ── ACTION MODAL ──────────────────────────────────────────────
async function openApplicantActions(applicantId) {
    document.getElementById('actionModal').classList.remove('hidden');
    document.getElementById('modalTitle').textContent = 'Loading...';
    document.getElementById('modalBody').innerHTML = '<p>Loading...</p>';
    await renderActionModal(applicantId);
}

/**
 * Renders modal with strict step-by-step flow:
 *
 * Step 1: Allocate Seat        — only if status=APPLIED
 * Step 2: Mark Doc Submitted   — only after seat allocated, doc still PENDING
 * Step 3: Verify Documents     — only if doc=SUBMITTED (cannot skip step 2)
 * Step 4: Mark Fee Paid        — only if doc=VERIFIED
 * Step 5: Confirm Admission    — only if fee=PAID
 *
 * Once ADMITTED → everything locked, show admission number only.
 */
async function renderActionModal(applicantId) {
    const modalBody = document.getElementById('modalBody');
    try {
        const res = await applicantAPI.getById(applicantId);
        const a = res.data;
        document.getElementById('modalTitle').textContent = `${a.firstName} ${a.lastName}`;

        const isAdmitted     = a.status === 'ADMITTED';
        const seatDone       = ['SEAT_ALLOCATED','DOCUMENTS_VERIFIED','ADMITTED'].includes(a.status);
        const docPending     = a.documentStatus === 'PENDING';
        const docSubmitted   = a.documentStatus === 'SUBMITTED';
        const docVerified    = a.documentStatus === 'VERIFIED';
        const feePaid        = a.feeStatus === 'PAID';

        const canAllocate    = a.status === 'APPLIED';
        const canSubmit      = seatDone && docPending && !isAdmitted;
        const canVerify      = docSubmitted && !isAdmitted;
        const canMarkFee     = docVerified && !feePaid && !isAdmitted;
        const canConfirm     = feePaid && !isAdmitted;

        if (isAdmitted) {
            modalBody.innerHTML = `
                <div style="background:#f8fafc;padding:12px;border-radius:8px;margin-bottom:12px;font-size:13px">
                    <p><strong>Program:</strong> ${a.programName} &nbsp;|&nbsp; <strong>Quota:</strong> ${a.quotaType}</p>
                    <p style="margin-top:6px">${statusBadge(a.status)} ${docBadge(a.documentStatus)} ${feeBadge(a.feeStatus)}</p>
                </div>
                <div class="success-msg" style="text-align:center;font-size:15px;padding:20px">
                    🎓 This applicant is fully admitted.<br><br>
                    <strong style="font-size:17px">${a.admissionNumber}</strong>
                </div>`;
            return;
        }

        const row = (step, label, desc, btnLabel, btnClass, canClick, isDone, onclick) => `
            <div class="action-row">
                <div>
                    <div class="action-label">${step} — ${label}</div>
                    <div class="action-desc">${desc}</div>
                </div>
                <button class="btn btn-sm ${isDone ? 'btn-gray' : (canClick ? btnClass : 'btn-gray')}"
                    onclick="${onclick}" ${(isDone || !canClick) ? 'disabled' : ''}>
                    ${isDone ? '✅ Done' : btnLabel}
                </button>
            </div>`;

        modalBody.innerHTML = `
            <div style="background:#f8fafc;padding:12px;border-radius:8px;margin-bottom:12px;font-size:13px">
                <p><strong>Program:</strong> ${a.programName} &nbsp;|&nbsp; <strong>Quota:</strong> ${a.quotaType} &nbsp;|&nbsp; <strong>Mode:</strong> ${a.admissionMode}</p>
                <p style="margin-top:6px">${statusBadge(a.status)} ${docBadge(a.documentStatus)} ${feeBadge(a.feeStatus)}</p>
            </div>

            ${row('Step 1','Allocate Seat',`Lock a seat in the <strong>${a.quotaType}</strong> quota`,
                'Allocate Seat','btn-primary', canAllocate, seatDone, `doAllocateSeat(${a.id})`)}

            ${row('Step 2','Mark Documents Submitted','Student has physically submitted documents',
                'Mark Submitted','btn-warning', canSubmit, docSubmitted||docVerified, `doUpdateDoc(${a.id},'SUBMITTED')`)}

            ${row('Step 3','Verify Documents','Officer confirms all documents are valid and complete',
                'Verify ✓','btn-success', canVerify, docVerified, `doUpdateDoc(${a.id},'VERIFIED')`)}

            ${row('Step 4','Mark Fee as Paid','Confirm fee payment received',
                'Mark Fee Paid','btn-success', canMarkFee, feePaid, `doUpdateFee(${a.id},'PAID')`)}

            ${row('Step 5','Confirm Admission','Generates unique immutable admission number',
                '🎓 Confirm','btn-primary', canConfirm, false, `doConfirmAdmission(${a.id})`)}

            <div id="modalActionMsg" style="margin-top:12px"></div>`;

    } catch (err) { modalBody.innerHTML = `<p class="error-msg">${err.message}</p>`; }
}

function closeModal() { document.getElementById('actionModal').classList.add('hidden'); }
document.getElementById('actionModal')?.addEventListener('click', e => { if (e.target.id==='actionModal') closeModal(); });

async function doAllocateSeat(id) {
    try {
        await applicantAPI.allocateSeat(id);
        showModalMsg('✅ Seat allocated!', true);
        loadApplicants(); loadDashboard();
        await renderActionModal(id);
    } catch (err) { showModalMsg('❌ ' + err.message, false); }
}

async function doUpdateDoc(id, status) {
    try {
        await applicantAPI.updateDocStatus(id, status);
        showModalMsg(`✅ Documents → ${status}`, true);
        loadApplicants();
        await renderActionModal(id);
    } catch (err) { showModalMsg('❌ ' + err.message, false); }
}

async function doUpdateFee(id, status) {
    try {
        await applicantAPI.updateFeeStatus(id, status);
        showModalMsg('✅ Fee marked PAID!', true);
        loadApplicants();
        await renderActionModal(id);
    } catch (err) { showModalMsg('❌ ' + err.message, false); }
}

async function doConfirmAdmission(id) {
    try {
        const res = await applicantAPI.confirm(id);
        showModalMsg('🎓 ADMITTED! Number: ' + res.data.admissionNumber, true);
        loadApplicants(); loadDashboard();
        await renderActionModal(id);
    } catch (err) { showModalMsg('❌ ' + err.message, false); }
}

function showModalMsg(msg, ok) {
    const el = document.getElementById('modalActionMsg');
    if (el) { el.className = ok ? 'success-msg' : 'error-msg'; el.textContent = msg; }
}

// ── PENDING DOCS & FEES ───────────────────────────────────────
async function loadPendingDocs() {
    const tbody = document.getElementById('pendingDocsBody');
    try {
        const res = await applicantAPI.pendingDocs();
        const list = res.data || [];
        tbody.innerHTML = !list.length ? '<tr><td colspan="6" class="text-center">No pending documents 🎉</td></tr>'
            : list.map(a => `<tr>
                <td>${a.firstName} ${a.lastName}</td><td>${a.email}</td>
                <td>${a.programName}</td><td>${a.quotaType}</td>
                <td>${docBadge(a.documentStatus)}</td>
                <td>
                    <button class="btn btn-sm btn-gray" onclick="doUpdateDocExternal(${a.id},'SUBMITTED')"
                        ${a.documentStatus !== 'PENDING' ? 'disabled' : ''}>Submitted</button>
                    <button class="btn btn-sm btn-success" onclick="doUpdateDocExternal(${a.id},'VERIFIED')"
                        ${a.documentStatus !== 'SUBMITTED' ? 'disabled title="Mark submitted first"' : ''}>Verified</button>
                </td>
              </tr>`).join('');
    } catch (err) { tbody.innerHTML = `<tr><td colspan="6" class="text-red text-center">${err.message}</td></tr>`; }
}
async function doUpdateDocExternal(id, status) {
    try { await applicantAPI.updateDocStatus(id, status); loadPendingDocs(); } catch (err) { alert('❌ ' + err.message); }
}

async function loadPendingFees() {
    const tbody = document.getElementById('pendingFeesBody');
    try {
        const res = await applicantAPI.pendingFees();
        const list = res.data || [];
        tbody.innerHTML = !list.length ? '<tr><td colspan="6" class="text-center">No pending fees 🎉</td></tr>'
            : list.map(a => `<tr>
                <td>${a.firstName} ${a.lastName}</td><td>${a.email}</td>
                <td>${a.programName}</td><td>${statusBadge(a.status)}</td>
                <td>${feeBadge(a.feeStatus)}</td>
                <td><button class="btn btn-sm btn-success" onclick="doUpdateFeeExternal(${a.id})">Mark Paid ✓</button></td>
              </tr>`).join('');
    } catch (err) { tbody.innerHTML = `<tr><td colspan="6" class="text-red text-center">${err.message}</td></tr>`; }
}
async function doUpdateFeeExternal(id) {
    try { await applicantAPI.updateFeeStatus(id, 'PAID'); loadPendingFees(); } catch (err) { alert(err.message); }
}

// ── FORMS SETUP ───────────────────────────────────────────────
function setupAllForms() {

    // Institution form
    document.getElementById('institutionForm')?.addEventListener('submit', async e => {
        e.preventDefault();
        const msg = document.getElementById('instFormMsg');
        const data = { name: document.getElementById('instName').value.trim(), code: document.getElementById('instCode').value.trim().toUpperCase(), email: document.getElementById('instEmail').value.trim(), phone: document.getElementById('instPhone').value.trim(), address: document.getElementById('instAddress').value.trim(), active: true };
        try {
            await institutionAPI.create(data);
            msg.className='success-msg'; msg.textContent=`✅ Institution "${data.name}" created!`; msg.classList.remove('hidden');
            document.getElementById('institutionForm').reset(); loadInstitutionsTable();
        } catch (err) { msg.className='error-msg'; msg.textContent='❌ '+err.message; msg.classList.remove('hidden'); }
    });

    // Campus form
    document.getElementById('campusForm')?.addEventListener('submit', async e => {
        e.preventDefault();
        const instId = document.getElementById('campusInstSelect').value;
        const name = document.getElementById('campusName').value.trim();
        const loc = document.getElementById('campusLocation').value.trim();
        const msg = document.getElementById('campusFormMsg');
        if (!instId) { msg.className='error-msg'; msg.textContent='Select an Institution first.'; msg.classList.remove('hidden'); return; }
        try {
            await campusAPI.create({ name, location: loc, active: true }, instId);
            msg.className='success-msg'; msg.textContent=`✅ Campus "${name}" created!`; msg.classList.remove('hidden');
            document.getElementById('campusName').value=''; document.getElementById('campusLocation').value=''; loadCampusesTable();
        } catch (err) { msg.className='error-msg'; msg.textContent='❌ '+err.message; msg.classList.remove('hidden'); }
    });

    // Department form
    document.getElementById('departmentForm')?.addEventListener('submit', async e => {
        e.preventDefault();
        const campusId = document.getElementById('deptCampusSelect').value;
        const name = document.getElementById('deptName').value.trim();
        const code = document.getElementById('deptCode').value.trim().toUpperCase();
        const desc = document.getElementById('deptDesc').value.trim();
        const msg = document.getElementById('deptFormMsg');
        if (!campusId) { msg.className='error-msg'; msg.textContent='Select a Campus first.'; msg.classList.remove('hidden'); return; }
        try {
            await departmentAPI.create({ name, code, description: desc, active: true }, campusId);
            msg.className='success-msg'; msg.textContent=`✅ Department "${name}" (${code}) created!`; msg.classList.remove('hidden');
            document.getElementById('deptName').value=''; document.getElementById('deptCode').value=''; document.getElementById('deptDesc').value=''; loadDepartmentsTable();
        } catch (err) { msg.className='error-msg'; msg.textContent='❌ '+err.message; msg.classList.remove('hidden'); }
    });

    // Program form
    document.getElementById('programForm')?.addEventListener('submit', async e => {
        e.preventDefault();
        const errorDiv = document.getElementById('programFormError');
        errorDiv.classList.add('hidden');
        const departmentId = parseInt(document.getElementById('progDeptSelect').value);
        if (!departmentId) { errorDiv.textContent='Select Institution → Campus → Department first.'; errorDiv.classList.remove('hidden'); return; }
        const form = document.getElementById('programForm');
        const data = Object.fromEntries(new FormData(form));
        data.departmentId=departmentId; data.totalIntake=parseInt(data.totalIntake); data.kcetSeats=parseInt(data.kcetSeats); data.comedkSeats=parseInt(data.comedkSeats); data.managementSeats=parseInt(data.managementSeats); data.supernumerarySeats=parseInt(data.supernumerarySeats)||0;
        const sum = data.kcetSeats+data.comedkSeats+data.managementSeats;
        if (sum !== data.totalIntake) { errorDiv.textContent=`Seat totals don't match: ${data.kcetSeats}+${data.comedkSeats}+${data.managementSeats}=${sum} ≠ ${data.totalIntake}`; errorDiv.classList.remove('hidden'); return; }
        try {
            const res = await programAPI.create(data);
            alert(`✅ Program "${res.data.name}" created!\nDepartment: ${res.data.departmentName}\nTotal Intake: ${res.data.totalIntake}`);
            form.reset();
            document.getElementById('progCampusSelect').innerHTML='<option value="">— Select Campus —</option>';
            document.getElementById('progDeptSelect').innerHTML='<option value="">— Select Department —</option>';
            document.getElementById('seatValidationMsg').textContent='';
            toggleProgramForm(); loadPrograms();
        } catch (err) { errorDiv.textContent='❌ '+err.message; errorDiv.classList.remove('hidden'); }
    });

    // ── APPLICANT FORM — with all validations ─────────────────
    const appForm = document.getElementById('applicantForm');
    if (appForm) {
        // Wire mode↔quota auto-filter
        appForm.querySelector('[name="admissionMode"]')?.addEventListener('change', enforceAdmissionModeQuota);

        appForm.addEventListener('submit', async e => {
            e.preventDefault();
            const errorDiv = document.getElementById('applicantFormError');
            errorDiv.classList.add('hidden');
            const data = Object.fromEntries(new FormData(appForm));

            // 1. Phone: exactly 10 digits
            if (!/^\d{10}$/.test(data.phone.replace(/\s/g,''))) {
                return showFormError(errorDiv, 'Phone number must be exactly 10 digits (numbers only).');
            }

            // 2. DOB: cannot be today or future
            const dob = new Date(data.dateOfBirth);
            const today = new Date(); today.setHours(0,0,0,0);
            if (dob >= today) {
                return showFormError(errorDiv, 'Date of birth cannot be today or a future date.');
            }

            // 3. Qualifying marks: 0 to 100
            const marks = parseFloat(data.qualifyingMarks);
            if (isNaN(marks) || marks < 0 || marks > 100) {
                return showFormError(errorDiv, 'Qualifying marks must be between 0 and 100.');
            }

            // 4. Government mode + Management quota = invalid
            if (data.admissionMode === 'GOVERNMENT' && data.quotaType === 'MANAGEMENT') {
                return showFormError(errorDiv, 'Government admission mode cannot use Management quota. Select KCET or COMEDK.');
            }

            // 5. Management mode + KCET/COMEDK quota = invalid
            if (data.admissionMode === 'MANAGEMENT' && (data.quotaType === 'KCET' || data.quotaType === 'COMEDK')) {
                return showFormError(errorDiv, 'Management admission mode cannot use KCET or COMEDK quota. Select Management quota.');
            }

            // 6. Program required
            if (!data.programId) {
                return showFormError(errorDiv, 'Please select a program.');
            }

            data.programId = parseInt(data.programId);
            data.qualifyingMarks = marks;

            try {
                const res = await applicantAPI.create(data);
                alert(`✅ Applicant created!\nName: ${res.data.firstName} ${res.data.lastName}\nID: ${res.data.id}`);
                appForm.reset();
                navigateTo('applicants');
            } catch (err) { showFormError(errorDiv, err.message); }
        });
    }
}

function showFormError(div, msg) {
    div.textContent = '❌ ' + msg;
    div.classList.remove('hidden');
    div.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

/**
 * Filters quota options based on admission mode selection.
 * Government → KCET, COMEDK, Supernumerary only
 * Management → MANAGEMENT, Supernumerary only
 */
function enforceAdmissionModeQuota() {
    const modeEl  = document.querySelector('#applicantForm [name="admissionMode"]');
    const quotaEl = document.querySelector('#applicantForm [name="quotaType"]');
    if (!modeEl || !quotaEl) return;
    const mode = modeEl.value;
    const opts = [
        { value: 'KCET',           text: 'KCET',           modes: ['GOVERNMENT'] },
        { value: 'COMEDK',         text: 'COMEDK',         modes: ['GOVERNMENT'] },
        { value: 'MANAGEMENT',     text: 'Management',     modes: ['MANAGEMENT'] },
        { value: 'SUPERNUMERARY',  text: 'Supernumerary',  modes: ['GOVERNMENT','MANAGEMENT'] },
    ];
    const currentVal = quotaEl.value;
    quotaEl.innerHTML = '';
    opts.forEach(o => {
        if (!mode || o.modes.includes(mode)) {
            const el = document.createElement('option');
            el.value = o.value; el.textContent = o.text;
            if (o.value === currentVal) el.selected = true;
            quotaEl.appendChild(el);
        }
    });
}

// ── SHARED HELPERS ────────────────────────────────────────────
async function populateInstitutionSelect(selectId, allOption=false) {
    const sel = document.getElementById(selectId);
    if (!sel) return;
    try {
        const res = await institutionAPI.getAll();
        sel.innerHTML = allOption ? '<option value="">All Institutions</option>' : '<option value="">— Select Institution —</option>';
        (res.data||[]).forEach(i => sel.innerHTML += `<option value="${i.id}">${i.name} (${i.code})</option>`);
    } catch(e){}
}

function statusBadge(s) {
    const m = {'APPLIED':'badge-gray','SEAT_ALLOCATED':'badge-blue','DOCUMENTS_VERIFIED':'badge-orange','ADMITTED':'badge-green'};
    return `<span class="badge ${m[s]||'badge-gray'}">${s.replace(/_/g,' ')}</span>`;
}
function docBadge(s) {
    const m = {'PENDING':'badge-red','SUBMITTED':'badge-orange','VERIFIED':'badge-green'};
    return `<span class="badge ${m[s]||'badge-gray'}">${s}</span>`;
}
function feeBadge(s) {
    return `<span class="badge ${s==='PAID'?'badge-green':'badge-red'}">${s}</span>`;
}