/**
 * api.js — Centralized API communication layer.
 *
 * WHY A CENTRALIZED API MODULE?
 *   - Single place to manage JWT token injection into headers
 *   - Consistent error handling across all API calls
 *   - Base URL defined once — easy to change for deployment
 *   - Auto-redirect to login on 401 (token expired)
 *
 * HOW JWT IS USED:
 *   After login, the server returns a token.
 *   We store it in localStorage.
 *   Every subsequent API call sends it in the Authorization header:
 *     Authorization: Bearer eyJhbGciOiJIUzI1NiJ9...
 *   The backend's JwtAuthFilter validates this token on every request.
 */

const BASE_URL = 'http://localhost:8080/api';

/**
 * Core API call function.
 * Automatically injects JWT token into every request.
 *
 * @param {string} endpoint  - API path, e.g., '/applicants'
 * @param {string} method    - HTTP method: GET, POST, PUT, DELETE
 * @param {object} body      - Request body (optional, for POST/PUT)
 * @returns {Promise<object>} - Parsed JSON response
 */
async function apiCall(endpoint, method = 'GET', body = null) {
    const token = localStorage.getItem('jwtToken');

    const headers = {
        'Content-Type': 'application/json',
    };

    // Inject JWT token if available
    // Format: "Bearer " + token (space is required!)
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const config = {
        method,
        headers,
    };

    // Only add body for non-GET requests
    if (body && method !== 'GET') {
        config.body = JSON.stringify(body);
    }

    try {
        const response = await fetch(`${BASE_URL}${endpoint}`, config);

        // 401 Unauthorized = token expired or invalid → redirect to login
        if (response.status === 401) {
            localStorage.clear();
            window.location.href = '/index.html';
            return;
        }

        const data = await response.json();

        // Our backend always returns { success: bool, message: string, data: any }
        if (!response.ok) {
            throw new Error(data.message || `HTTP error ${response.status}`);
        }

        return data;

    } catch (error) {
        // Network error (server down, CORS issue, etc.)
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
            throw new Error('Cannot connect to server. Is the backend running on port 8080?');
        }
        throw error;
    }
}

/* ============================================================
   AUTH API
   ============================================================ */

/** POST /auth/login — returns JWT token */
const authAPI = {
    login: (username, password) =>
        apiCall('/auth/login', 'POST', { username, password }),

    register: (data) =>
        apiCall('/auth/register', 'POST', data),
};

/* ============================================================
   MASTER DATA API
   ============================================================ */

const institutionAPI = {
    getAll:  ()     => apiCall('/institutions'),
    getById: (id)   => apiCall(`/institutions/${id}`),
    create:  (data) => apiCall('/institutions', 'POST', data),
};

const campusAPI = {
    getByInstitution: (instId) => apiCall(`/campuses?institutionId=${instId}`),
    create: (data, instId)     => apiCall(`/campuses?institutionId=${instId}`, 'POST', data),
};

const departmentAPI = {
    getByCampus: (campusId) => apiCall(`/departments?campusId=${campusId}`),
    create: (data, campusId) => apiCall(`/departments?campusId=${campusId}`, 'POST', data),
};

const programAPI = {
    getAll:  ()     => apiCall('/programs'),
    getById: (id)   => apiCall(`/programs/${id}`),
    create:  (data) => apiCall('/programs', 'POST', data),
};

/* ============================================================
   ADMISSION / APPLICANT API
   ============================================================ */

const applicantAPI = {
    getAll:    ()   => apiCall('/applicants'),
    getById:   (id) => apiCall(`/applicants/${id}`),
    create:    (data) => apiCall('/applicants', 'POST', data),

    // Seat allocation — critical: may throw QuotaFullException (409)
    allocateSeat: (id) => apiCall(`/applicants/${id}/allocate-seat`, 'POST'),

    // Document status: PENDING | SUBMITTED | VERIFIED
    updateDocStatus: (id, status) =>
        apiCall(`/applicants/${id}/document-status`, 'PUT', { documentStatus: status }),

    // Fee status: PENDING | PAID
    updateFeeStatus: (id, status) =>
        apiCall(`/applicants/${id}/fee-status`, 'PUT', { feeStatus: status }),

    // Confirm admission — generates unique admission number
    confirm: (id) => apiCall(`/applicants/${id}/confirm`, 'POST'),

    // Dashboard lists
    pendingDocs: () => apiCall('/applicants/pending-documents'),
    pendingFees: () => apiCall('/applicants/pending-fees'),
};

const dashboardAPI = {
    get: () => apiCall('/dashboard'),
};
