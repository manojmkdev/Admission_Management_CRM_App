/**
 * auth.js — Handles login form, JWT token storage, and session management.
 *
 * JWT STORAGE STRATEGY:
 *   We store the JWT in localStorage.
 *   On every page load, we check if a valid token exists.
 *   If not → redirect to login page.
 *
 * SECURITY NOTE (for interview):
 *   localStorage is vulnerable to XSS attacks.
 *   More secure alternatives: httpOnly cookies (not accessible by JS).
 *   For this assignment, localStorage is acceptable.
 */

// ============================================================
// LOGIN PAGE LOGIC
// ============================================================

const loginForm = document.getElementById('loginForm');

if (loginForm) {
    // If already logged in, skip login page
    if (localStorage.getItem('jwtToken')) {
        window.location.href = 'pages/dashboard.html';
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('loginError');
        const loginBtn = document.getElementById('loginBtn');

        errorDiv.classList.add('hidden');
        loginBtn.innerHTML = '<span class="spinner"></span> Logging in...';
        loginBtn.disabled = true;

        try {
            const response = await authAPI.login(username, password);

            if (response.success) {
                const { token, role, fullName, username: uname } = response.data;

                // Store JWT token and user info in localStorage
                localStorage.setItem('jwtToken', token);
                localStorage.setItem('userRole', role);
                localStorage.setItem('userFullName', fullName);
                localStorage.setItem('username', uname);

                // Redirect to dashboard
                window.location.href = 'pages/dashboard.html';
            }
        } catch (error) {
            errorDiv.textContent = error.message || 'Login failed. Check credentials.';
            errorDiv.classList.remove('hidden');
        } finally {
            loginBtn.innerHTML = 'Login';
            loginBtn.disabled = false;
        }
    });
}

// ============================================================
// SESSION GUARD — Runs on every protected page
// ============================================================

/**
 * Checks if user is authenticated. If not, redirect to login.
 * Call this at the top of every protected page.
 */
function requireAuth() {
    const token = localStorage.getItem('jwtToken');
    if (!token) {
        window.location.href = '../index.html';
        return null;
    }
    return {
        token,
        role:     localStorage.getItem('userRole'),
        fullName: localStorage.getItem('userFullName'),
        username: localStorage.getItem('username'),
    };
}

/**
 * Logs out the user: clears localStorage and redirects to login.
 * JWT is stateless — we don't call any server endpoint to "invalidate" it.
 * (In production: implement token blacklist or use short expiry + refresh tokens.)
 */
function logout() {
    localStorage.clear();
    window.location.href = '../index.html';
}

// Bind logout button if it exists on the page
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
}
