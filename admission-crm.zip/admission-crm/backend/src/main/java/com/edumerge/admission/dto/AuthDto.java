package com.edumerge.admission.dto;

public class AuthDto {

    public static class LoginRequest {
        private String username;
        private String password;
        public LoginRequest() {}
        public String getUsername() { return username; }
        public void setUsername(String u) { this.username = u; }
        public String getPassword() { return password; }
        public void setPassword(String p) { this.password = p; }
    }

    public static class LoginResponse {
        private String token;
        private String username;
        private String role;
        private String fullName;
        private String message;
        public LoginResponse() {}
        public String getToken()       { return token; }
        public void setToken(String t) { this.token = t; }
        public String getUsername()    { return username; }
        public void setUsername(String u){ this.username = u; }
        public String getRole()        { return role; }
        public void setRole(String r)  { this.role = r; }
        public String getFullName()    { return fullName; }
        public void setFullName(String f){ this.fullName = f; }
        public String getMessage()     { return message; }
        public void setMessage(String m){ this.message = m; }

        public static Builder builder() { return new Builder(); }
        public static class Builder {
            private final LoginResponse r = new LoginResponse();
            public Builder token(String v)    { r.token = v; return this; }
            public Builder username(String v) { r.username = v; return this; }
            public Builder role(String v)     { r.role = v; return this; }
            public Builder fullName(String v) { r.fullName = v; return this; }
            public Builder message(String v)  { r.message = v; return this; }
            public LoginResponse build()      { return r; }
        }
    }

    public static class RegisterRequest {
        private String username;
        private String password;
        private String fullName;
        private String role;
        public RegisterRequest() {}
        public String getUsername()    { return username; }
        public void setUsername(String u){ this.username = u; }
        public String getPassword()    { return password; }
        public void setPassword(String p){ this.password = p; }
        public String getFullName()    { return fullName; }
        public void setFullName(String f){ this.fullName = f; }
        public String getRole()        { return role; }
        public void setRole(String r)  { this.role = r; }
    }
}
