package com.edumerge.admission.repository;

import com.edumerge.admission.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    List<Department> findByCampusIdAndActiveTrue(Long campusId);
}
