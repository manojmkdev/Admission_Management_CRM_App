package com.edumerge.admission.exception;

/** Thrown when trying to allocate a seat in a quota that is already full. */
public class QuotaFullException extends RuntimeException {
    public QuotaFullException(String quotaType) {
        super("No seats available in quota: " + quotaType + ". Seat allocation is blocked.");
    }
}
