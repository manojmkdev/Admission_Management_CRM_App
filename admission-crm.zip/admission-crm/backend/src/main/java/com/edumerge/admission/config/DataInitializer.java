package com.edumerge.admission.config;

import com.edumerge.admission.entity.User;
import com.edumerge.admission.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            userRepository.save(User.builder().username("admin").password(passwordEncoder.encode("admin123")).fullName("System Administrator").role(User.Role.ADMIN).active(true).build());
            userRepository.save(User.builder().username("officer1").password(passwordEncoder.encode("officer123")).fullName("Admission Officer").role(User.Role.ADMISSION_OFFICER).active(true).build());
            userRepository.save(User.builder().username("management").password(passwordEncoder.encode("mgmt123")).fullName("Management User").role(User.Role.MANAGEMENT).active(true).build());
        }
    }
}
