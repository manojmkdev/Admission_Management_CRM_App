package com.edumerge.admission.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "programs")
public class Program {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 20)
    private String code;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private CourseType courseType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private EntryType entryType;

    @Column(nullable = false)
    private String academicYear;

    @Column(nullable = false)
    private Integer totalIntake;

    @Column(nullable = false)
    private Integer kcetSeats;

    @Column(nullable = false)
    private Integer comedkSeats;

    @Column(nullable = false)
    private Integer managementSeats;

    @Column(nullable = false)
    private Integer supernumerarySeats = 0;

    @Column(nullable = false)
    private Integer kcetAllocated = 0;

    @Column(nullable = false)
    private Integer comedkAllocated = 0;

    @Column(nullable = false)
    private Integer managementAllocated = 0;

    @Column(nullable = false)
    private Integer supernumeraryAllocated = 0;

    @Column(nullable = false)
    private boolean active = true;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    @JsonIgnore
    @OneToMany(mappedBy = "program", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Applicant> applicants;

    public Program() {}


    @JsonProperty("departmentName")
    public String getDepartmentName() {
        return department != null ? department.getName() : "N/A";
    }

    @JsonProperty("kcetAvailable")
    public int getKcetAvailable() { return kcetSeats - kcetAllocated; }

    @JsonProperty("comedkAvailable")
    public int getComedkAvailable() { return comedkSeats - comedkAllocated; }

    @JsonProperty("managementAvailable")
    public int getManagementAvailable() { return managementSeats - managementAllocated; }

    @JsonProperty("totalAdmitted")
    public int getTotalAdmitted() { return kcetAllocated + comedkAllocated + managementAllocated; }

    @JsonProperty("totalRemaining")
    public int getTotalRemaining() { return totalIntake - getTotalAdmitted(); }

    public boolean isQuotaAvailable(QuotaType quotaType) {
        return switch (quotaType) {
            case KCET          -> getKcetAvailable() > 0;
            case COMEDK        -> getComedkAvailable() > 0;
            case MANAGEMENT    -> getManagementAvailable() > 0;
            case SUPERNUMERARY -> (supernumerarySeats - supernumeraryAllocated) > 0;
        };
    }
    

    public Long getId()                             { return id; }
    public void setId(Long id)                      { this.id = id; }
    public String getName()                         { return name; }
    public void setName(String n)                   { this.name = n; }
    public String getCode()                         { return code; }
    public void setCode(String c)                   { this.code = c; }
    public CourseType getCourseType()               { return courseType; }
    public void setCourseType(CourseType t)         { this.courseType = t; }
    public EntryType getEntryType()                 { return entryType; }
    public void setEntryType(EntryType t)           { this.entryType = t; }
    public String getAcademicYear()                 { return academicYear; }
    public void setAcademicYear(String y)           { this.academicYear = y; }
    public Integer getTotalIntake()                 { return totalIntake; }
    public void setTotalIntake(Integer t)           { this.totalIntake = t; }
    public Integer getKcetSeats()                   { return kcetSeats; }
    public void setKcetSeats(Integer s)             { this.kcetSeats = s; }
    public Integer getComedkSeats()                 { return comedkSeats; }
    public void setComedkSeats(Integer s)           { this.comedkSeats = s; }
    public Integer getManagementSeats()             { return managementSeats; }
    public void setManagementSeats(Integer s)       { this.managementSeats = s; }
    public Integer getSupernumerarySeats()          { return supernumerarySeats; }
    public void setSupernumerarySeats(Integer s)    { this.supernumerarySeats = s; }
    public Integer getKcetAllocated()               { return kcetAllocated; }
    public void setKcetAllocated(Integer a)         { this.kcetAllocated = a; }
    public Integer getComedkAllocated()             { return comedkAllocated; }
    public void setComedkAllocated(Integer a)       { this.comedkAllocated = a; }
    public Integer getManagementAllocated()         { return managementAllocated; }
    public void setManagementAllocated(Integer a)   { this.managementAllocated = a; }
    public Integer getSupernumeraryAllocated()      { return supernumeraryAllocated; }
    public void setSupernumeraryAllocated(Integer a){ this.supernumeraryAllocated = a; }
    public boolean isActive()                       { return active; }
    public void setActive(boolean a)                { this.active = a; }
    public Department getDepartment()               { return department; }
    public void setDepartment(Department d)         { this.department = d; }
    public List<Applicant> getApplicants()          { return applicants; }
    public void setApplicants(List<Applicant> a)    { this.applicants = a; }

    public enum CourseType  { UG, PG }
    public enum EntryType   { REGULAR, LATERAL }
    public enum QuotaType   { KCET, COMEDK, MANAGEMENT, SUPERNUMERARY }
}
