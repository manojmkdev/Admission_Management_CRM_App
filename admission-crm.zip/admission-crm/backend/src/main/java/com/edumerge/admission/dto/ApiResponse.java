package com.edumerge.admission.dto;

public class ApiResponse<T> {
    private boolean success;
    private String message;
    private T data;

    public ApiResponse() {}
    public ApiResponse(boolean success, String message, T data) {
        this.success = success; this.message = message; this.data = data;
    }

    public static <T> ApiResponse<T> success(String message, T data) {
        return new ApiResponse<>(true, message, data);
    }
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(false, message, null);
    }

    public boolean isSuccess()          { return success; }
    public void setSuccess(boolean s)   { this.success = s; }
    public String getMessage()          { return message; }
    public void setMessage(String m)    { this.message = m; }
    public T getData()                  { return data; }
    public void setData(T d)            { this.data = d; }
}
