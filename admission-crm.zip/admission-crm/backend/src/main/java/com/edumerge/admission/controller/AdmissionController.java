package com.edumerge.admission.controller;

import com.edumerge.admission.dto.*;
import com.edumerge.admission.service.AdmissionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class AdmissionController {

    private final AdmissionService admissionService;

    public AdmissionController(AdmissionService admissionService) {
        this.admissionService = admissionService;
    }

    @PostMapping("/applicants")
    public ResponseEntity<ApiResponse<ApplicantDto.Response>> createApplicant(
            @RequestBody ApplicantDto.CreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Applicant created", admissionService.createApplicant(request)));
    }

    @GetMapping("/applicants")
    public ResponseEntity<ApiResponse<List<ApplicantDto.Response>>> getAllApplicants() {
        return ResponseEntity.ok(ApiResponse.success("OK", admissionService.getAllApplicants()));
    }

    @GetMapping("/applicants/{id}")
    public ResponseEntity<ApiResponse<ApplicantDto.Response>> getApplicant(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("OK", admissionService.getApplicantById(id)));
    }

    @PostMapping("/applicants/{id}/allocate-seat")
    public ResponseEntity<ApiResponse<ApplicantDto.Response>> allocateSeat(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Seat allocated", admissionService.allocateSeat(id)));
    }

    @PutMapping("/applicants/{id}/document-status")
    public ResponseEntity<ApiResponse<ApplicantDto.Response>> updateDocumentStatus(
            @PathVariable Long id, @RequestBody ApplicantDto.UpdateDocumentStatus request) {
        return ResponseEntity.ok(ApiResponse.success("Document status updated",
                admissionService.updateDocumentStatus(id, request.getDocumentStatus())));
    }

    @PutMapping("/applicants/{id}/fee-status")
    public ResponseEntity<ApiResponse<ApplicantDto.Response>> updateFeeStatus(
            @PathVariable Long id, @RequestBody ApplicantDto.UpdateFeeStatus request) {
        return ResponseEntity.ok(ApiResponse.success("Fee status updated",
                admissionService.updateFeeStatus(id, request.getFeeStatus())));
    }

    @PostMapping("/applicants/{id}/confirm")
    public ResponseEntity<ApiResponse<ApplicantDto.Response>> confirmAdmission(@PathVariable Long id) {
        ApplicantDto.Response response = admissionService.confirmAdmission(id);
        return ResponseEntity.ok(ApiResponse.success(
                "Admission confirmed! Number: " + response.getAdmissionNumber(), response));
    }

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardDto>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.success("OK", admissionService.getDashboard()));
    }

    @GetMapping("/applicants/pending-documents")
    public ResponseEntity<ApiResponse<List<ApplicantDto.Response>>> getPendingDocuments() {
        return ResponseEntity.ok(ApiResponse.success("OK", admissionService.getPendingDocuments()));
    }

    @GetMapping("/applicants/pending-fees")
    public ResponseEntity<ApiResponse<List<ApplicantDto.Response>>> getPendingFees() {
        return ResponseEntity.ok(ApiResponse.success("OK", admissionService.getPendingFees()));
    }
}
