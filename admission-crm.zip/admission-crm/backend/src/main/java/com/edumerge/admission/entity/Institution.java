package com.edumerge.admission.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "institutions")
public class Institution {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 200)
    private String name;

    @Column(length = 50, unique = true)
    private String code;

    @Column(length = 500)
    private String address;

    @Column(length = 100)
    private String email;

    @Column(length = 20)
    private String phone;

    @Column(nullable = false)
    private boolean active = true;

    // @JsonIgnore prevents infinite loop: Institution→Campus→Institution→Campus...
    @JsonIgnore
    @OneToMany(mappedBy = "institution", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Campus> campuses;

    public Institution() {}
    public Long getId()                    { return id; }
    public void setId(Long id)             { this.id = id; }
    public String getName()                { return name; }
    public void setName(String n)          { this.name = n; }
    public String getCode()                { return code; }
    public void setCode(String c)          { this.code = c; }
    public String getAddress()             { return address; }
    public void setAddress(String a)       { this.address = a; }
    public String getEmail()               { return email; }
    public void setEmail(String e)         { this.email = e; }
    public String getPhone()               { return phone; }
    public void setPhone(String p)         { this.phone = p; }
    public boolean isActive()              { return active; }
    public void setActive(boolean a)       { this.active = a; }
    public List<Campus> getCampuses()      { return campuses; }
    public void setCampuses(List<Campus> c){ this.campuses = c; }
}
