package com.edumerge.admission.dto;

public class ProgramDto {

    public static class CreateRequest {
        private String name, code, courseType, entryType, academicYear;
        private Integer totalIntake, kcetSeats, comedkSeats, managementSeats, supernumerarySeats;
        private Long departmentId;

        public String getName()                  { return name; }
        public void setName(String v)            { this.name = v; }
        public String getCode()                  { return code; }
        public void setCode(String v)            { this.code = v; }
        public String getCourseType()            { return courseType; }
        public void setCourseType(String v)      { this.courseType = v; }
        public String getEntryType()             { return entryType; }
        public void setEntryType(String v)       { this.entryType = v; }
        public String getAcademicYear()          { return academicYear; }
        public void setAcademicYear(String v)    { this.academicYear = v; }
        public Integer getTotalIntake()          { return totalIntake; }
        public void setTotalIntake(Integer v)    { this.totalIntake = v; }
        public Integer getKcetSeats()            { return kcetSeats; }
        public void setKcetSeats(Integer v)      { this.kcetSeats = v; }
        public Integer getComedkSeats()          { return comedkSeats; }
        public void setComedkSeats(Integer v)    { this.comedkSeats = v; }
        public Integer getManagementSeats()      { return managementSeats; }
        public void setManagementSeats(Integer v){ this.managementSeats = v; }
        public Integer getSupernumerarySeats()   { return supernumerarySeats; }
        public void setSupernumerarySeats(Integer v){ this.supernumerarySeats = v; }
        public Long getDepartmentId()            { return departmentId; }
        public void setDepartmentId(Long v)      { this.departmentId = v; }
    }

    public static class Response {
        private Long id;
        private String name, code, courseType, entryType, academicYear, departmentName;
        private Long departmentId;
        private Integer totalIntake, kcetSeats, kcetAllocated, kcetAvailable,
                        comedkSeats, comedkAllocated, comedkAvailable,
                        managementSeats, managementAllocated, managementAvailable,
                        supernumerarySeats, supernumeraryAllocated,
                        totalAdmitted, totalRemaining;

        public static Builder builder() { return new Builder(); }
        public static class Builder {
            private final Response r = new Response();
            public Builder id(Long v)                      { r.id = v; return this; }
            public Builder name(String v)                  { r.name = v; return this; }
            public Builder code(String v)                  { r.code = v; return this; }
            public Builder courseType(String v)            { r.courseType = v; return this; }
            public Builder entryType(String v)             { r.entryType = v; return this; }
            public Builder academicYear(String v)          { r.academicYear = v; return this; }
            public Builder departmentName(String v)        { r.departmentName = v; return this; }
            public Builder departmentId(Long v)            { r.departmentId = v; return this; }
            public Builder totalIntake(Integer v)          { r.totalIntake = v; return this; }
            public Builder kcetSeats(Integer v)            { r.kcetSeats = v; return this; }
            public Builder kcetAllocated(Integer v)        { r.kcetAllocated = v; return this; }
            public Builder kcetAvailable(Integer v)        { r.kcetAvailable = v; return this; }
            public Builder comedkSeats(Integer v)          { r.comedkSeats = v; return this; }
            public Builder comedkAllocated(Integer v)      { r.comedkAllocated = v; return this; }
            public Builder comedkAvailable(Integer v)      { r.comedkAvailable = v; return this; }
            public Builder managementSeats(Integer v)      { r.managementSeats = v; return this; }
            public Builder managementAllocated(Integer v)  { r.managementAllocated = v; return this; }
            public Builder managementAvailable(Integer v)  { r.managementAvailable = v; return this; }
            public Builder supernumerarySeats(Integer v)   { r.supernumerarySeats = v; return this; }
            public Builder supernumeraryAllocated(Integer v){ r.supernumeraryAllocated = v; return this; }
            public Builder totalAdmitted(Integer v)        { r.totalAdmitted = v; return this; }
            public Builder totalRemaining(Integer v)       { r.totalRemaining = v; return this; }
            public Response build()                        { return r; }
        }

        public Long getId()                    { return id; }
        public String getName()                { return name; }
        public String getCode()                { return code; }
        public String getCourseType()          { return courseType; }
        public String getEntryType()           { return entryType; }
        public String getAcademicYear()        { return academicYear; }
        public String getDepartmentName()      { return departmentName; }
        public Long getDepartmentId()          { return departmentId; }
        public Integer getTotalIntake()        { return totalIntake; }
        public Integer getKcetSeats()          { return kcetSeats; }
        public Integer getKcetAllocated()      { return kcetAllocated; }
        public Integer getKcetAvailable()      { return kcetAvailable; }
        public Integer getComedkSeats()        { return comedkSeats; }
        public Integer getComedkAllocated()    { return comedkAllocated; }
        public Integer getComedkAvailable()    { return comedkAvailable; }
        public Integer getManagementSeats()    { return managementSeats; }
        public Integer getManagementAllocated(){ return managementAllocated; }
        public Integer getManagementAvailable(){ return managementAvailable; }
        public Integer getSupernumerarySeats() { return supernumerarySeats; }
        public Integer getSupernumeraryAllocated(){ return supernumeraryAllocated; }
        public Integer getTotalAdmitted()      { return totalAdmitted; }
        public Integer getTotalRemaining()     { return totalRemaining; }
    }
}
