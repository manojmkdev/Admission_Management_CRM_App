package com.edumerge.admission.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "applicants")
public class Applicant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String firstName;
    @Column(nullable = false, length = 100)
    private String lastName;
    @Column(nullable = false, unique = true, length = 100)
    private String email;
    @Column(nullable = false, length = 15)
    private String phone;
    @Column(nullable = false)
    private LocalDate dateOfBirth;
    @Column(nullable = false, length = 10)
    private String gender;
    @Column(nullable = false, length = 200)
    private String address;
    @Column(nullable = false, length = 20)
    private String category;
    @Column(nullable = false, length = 50)
    private String qualifyingExam;
    @Column(nullable = false)
    private Double qualifyingMarks;
    @Column(length = 50)
    private String entranceRank;
    @Column(length = 100)
    private String allotmentNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Program.EntryType entryType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Program.QuotaType quotaType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AdmissionMode admissionMode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ApplicationStatus status = ApplicationStatus.APPLIED;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DocumentStatus documentStatus = DocumentStatus.PENDING;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private FeeStatus feeStatus = FeeStatus.PENDING;

    @Column(updatable = false)
    private LocalDateTime createdAt;


    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "program_id", nullable = false)
    private Program program;

    @JsonIgnore
    @OneToOne(mappedBy = "applicant", cascade = CascadeType.ALL)
    private Admission admission;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User createdBy;

    @PrePersist
    protected void onCreate() { createdAt = LocalDateTime.now();  }
   

    public Applicant() {}

    public Long getId()                              { return id; }
    public void setId(Long id)                       { this.id = id; }
    public String getFirstName()                     { return firstName; }
    public void setFirstName(String n)               { this.firstName = n; }
    public String getLastName()                      { return lastName; }
    public void setLastName(String n)                { this.lastName = n; }
    public String getEmail()                         { return email; }
    public void setEmail(String e)                   { this.email = e; }
    public String getPhone()                         { return phone; }
    public void setPhone(String p)                   { this.phone = p; }
    public LocalDate getDateOfBirth()                { return dateOfBirth; }
    public void setDateOfBirth(LocalDate d)          { this.dateOfBirth = d; }
    public String getGender()                        { return gender; }
    public void setGender(String g)                  { this.gender = g; }
    public String getAddress()                       { return address; }
    public void setAddress(String a)                 { this.address = a; }
    public String getCategory()                      { return category; }
    public void setCategory(String c)                { this.category = c; }
    public String getQualifyingExam()                { return qualifyingExam; }
    public void setQualifyingExam(String e)          { this.qualifyingExam = e; }
    public Double getQualifyingMarks()               { return qualifyingMarks; }
    public void setQualifyingMarks(Double m)         { this.qualifyingMarks = m; }
    public String getEntranceRank()                  { return entranceRank; }
    public void setEntranceRank(String r)            { this.entranceRank = r; }
    public String getAllotmentNumber()               { return allotmentNumber; }
    public void setAllotmentNumber(String a)         { this.allotmentNumber = a; }
    public Program.EntryType getEntryType()          { return entryType; }
    public void setEntryType(Program.EntryType t)    { this.entryType = t; }
    public Program.QuotaType getQuotaType()          { return quotaType; }
    public void setQuotaType(Program.QuotaType q)    { this.quotaType = q; }
    public AdmissionMode getAdmissionMode()          { return admissionMode; }
    public void setAdmissionMode(AdmissionMode m)    { this.admissionMode = m; }
    public ApplicationStatus getStatus()             { return status; }
    public void setStatus(ApplicationStatus s)       { this.status = s; }
    public DocumentStatus getDocumentStatus()        { return documentStatus; }
    public void setDocumentStatus(DocumentStatus d)  { this.documentStatus = d; }
    public FeeStatus getFeeStatus()                  { return feeStatus; }
    public void setFeeStatus(FeeStatus f)            { this.feeStatus = f; }
    public LocalDateTime getCreatedAt()              { return createdAt; }
    public Program getProgram()                      { return program; }
    public void setProgram(Program p)                { this.program = p; }
    public Admission getAdmission()                  { return admission; }
    public void setAdmission(Admission a)            { this.admission = a; }
    public User getCreatedBy()                       { return createdBy; }
    public void setCreatedBy(User u)                 { this.createdBy = u; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final Applicant a = new Applicant();
        public Builder firstName(String v)            { a.firstName = v; return this; }
        public Builder lastName(String v)             { a.lastName = v; return this; }
        public Builder email(String v)                { a.email = v; return this; }
        public Builder phone(String v)                { a.phone = v; return this; }
        public Builder dateOfBirth(LocalDate v)       { a.dateOfBirth = v; return this; }
        public Builder gender(String v)               { a.gender = v; return this; }
        public Builder address(String v)              { a.address = v; return this; }
        public Builder category(String v)             { a.category = v; return this; }
        public Builder qualifyingExam(String v)       { a.qualifyingExam = v; return this; }
        public Builder qualifyingMarks(Double v)      { a.qualifyingMarks = v; return this; }
        public Builder entranceRank(String v)         { a.entranceRank = v; return this; }
        public Builder allotmentNumber(String v)      { a.allotmentNumber = v; return this; }
        public Builder entryType(Program.EntryType v) { a.entryType = v; return this; }
        public Builder quotaType(Program.QuotaType v) { a.quotaType = v; return this; }
        public Builder admissionMode(AdmissionMode v) { a.admissionMode = v; return this; }
        public Builder program(Program v)             { a.program = v; return this; }
        public Builder status(ApplicationStatus v)    { a.status = v; return this; }
        public Builder documentStatus(DocumentStatus v){ a.documentStatus = v; return this; }
        public Builder feeStatus(FeeStatus v)         { a.feeStatus = v; return this; }
        public Builder createdBy(User u)              { a.createdBy = u; return this; }
        public Applicant build()                      { return a; }
    }

    public enum ApplicationStatus { APPLIED, SEAT_ALLOCATED, DOCUMENTS_VERIFIED, ADMITTED }
    public enum DocumentStatus    { PENDING, SUBMITTED, VERIFIED }
    public enum FeeStatus         { PENDING, PAID }
    public enum AdmissionMode     { GOVERNMENT, MANAGEMENT }
}
