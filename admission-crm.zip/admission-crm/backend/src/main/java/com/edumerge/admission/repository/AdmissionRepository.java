package com.edumerge.admission.repository;

import com.edumerge.admission.entity.Admission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface AdmissionRepository extends JpaRepository<Admission, Long> {
    Optional<Admission> findByAdmissionNumber(String admissionNumber);
    boolean existsByApplicantId(Long applicantId);

    @Query("SELECT COUNT(a) FROM Admission a WHERE a.admissionNumber LIKE :prefix%")
    long countByAdmissionNumberStartingWith(String prefix);
}
