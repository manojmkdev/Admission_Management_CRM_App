package com.edumerge.admission.service;

import com.edumerge.admission.dto.ApplicantDto;
import com.edumerge.admission.dto.DashboardDto;
import com.edumerge.admission.entity.*;
import com.edumerge.admission.exception.*;
import com.edumerge.admission.repository.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Year;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@Service
@Transactional
public class AdmissionService {

    private static final Logger log = Logger.getLogger(AdmissionService.class.getName());

    private final ApplicantRepository applicantRepository;
    private final ProgramRepository programRepository;
    private final AdmissionRepository admissionRepository;
    private final UserRepository userRepository;

    public AdmissionService(ApplicantRepository applicantRepository,
                            ProgramRepository programRepository,
                            AdmissionRepository admissionRepository,
                            UserRepository userRepository) {
        this.applicantRepository = applicantRepository;
        this.programRepository = programRepository;
        this.admissionRepository = admissionRepository;
        this.userRepository = userRepository;
    }

    // ── CREATE APPLICANT ──────────────────────────────────────

    public ApplicantDto.Response createApplicant(ApplicantDto.CreateRequest request) {
        Program program = programRepository.findById(request.getProgramId())
                .orElseThrow(() -> new ResourceNotFoundException("Program not found: " + request.getProgramId()));

        String currentUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        User officer = userRepository.findByUsername(currentUsername).orElse(null);

        Applicant applicant = Applicant.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .dateOfBirth(request.getDateOfBirth())
                .gender(request.getGender())
                .address(request.getAddress())
                .category(request.getCategory())
                .qualifyingExam(request.getQualifyingExam())
                .qualifyingMarks(request.getQualifyingMarks())
                .entranceRank(request.getEntranceRank())
                .allotmentNumber(request.getAllotmentNumber())
                .entryType(Program.EntryType.valueOf(request.getEntryType()))
                .quotaType(Program.QuotaType.valueOf(request.getQuotaType()))
                .admissionMode(Applicant.AdmissionMode.valueOf(request.getAdmissionMode()))
                .program(program)
                .status(Applicant.ApplicationStatus.APPLIED)
                .documentStatus(Applicant.DocumentStatus.PENDING)
                .feeStatus(Applicant.FeeStatus.PENDING)
                .createdBy(officer)
                .build();

        Applicant saved = applicantRepository.save(applicant);
        log.info("Applicant created: " + request.getFirstName() + " " + request.getLastName());
        return mapToResponse(saved);
    }

    // ── SEAT ALLOCATION ───────────────────────────────────────

    public ApplicantDto.Response allocateSeat(Long applicantId) {
        Applicant applicant = getApplicantEntity(applicantId);
        Program program = applicant.getProgram();
        Program.QuotaType quota = applicant.getQuotaType();

        // CRITICAL: block if quota is full
        if (!program.isQuotaAvailable(quota)) {
            log.warning("Seat allocation BLOCKED for applicant " + applicantId + " — quota " + quota + " is FULL");
            throw new QuotaFullException(quota.name());
        }

        // Increment the correct counter
        switch (quota) {
            case KCET         -> program.setKcetAllocated(program.getKcetAllocated() + 1);
            case COMEDK       -> program.setComedkAllocated(program.getComedkAllocated() + 1);
            case MANAGEMENT   -> program.setManagementAllocated(program.getManagementAllocated() + 1);
            case SUPERNUMERARY -> program.setSupernumeraryAllocated(program.getSupernumeraryAllocated() + 1);
        }

        applicant.setStatus(Applicant.ApplicationStatus.SEAT_ALLOCATED);
        programRepository.save(program);
        applicantRepository.save(applicant);
        log.info("Seat allocated: applicant " + applicantId + " in quota " + quota);
        return mapToResponse(applicant);
    }

    // ── DOCUMENT STATUS ───────────────────────────────────────

    public ApplicantDto.Response updateDocumentStatus(Long applicantId, String documentStatus) {
        Applicant applicant = getApplicantEntity(applicantId);
        Applicant.DocumentStatus ds = Applicant.DocumentStatus.valueOf(documentStatus.toUpperCase());
        applicant.setDocumentStatus(ds);
        if (ds == Applicant.DocumentStatus.VERIFIED) {
            applicant.setStatus(Applicant.ApplicationStatus.DOCUMENTS_VERIFIED);
        }
        return mapToResponse(applicantRepository.save(applicant));
    }

    // ── FEE STATUS ────────────────────────────────────────────

    public ApplicantDto.Response updateFeeStatus(Long applicantId, String feeStatus) {
        Applicant applicant = getApplicantEntity(applicantId);
        applicant.setFeeStatus(Applicant.FeeStatus.valueOf(feeStatus.toUpperCase()));
        return mapToResponse(applicantRepository.save(applicant));
    }

    // ── CONFIRM ADMISSION ─────────────────────────────────────

    public ApplicantDto.Response confirmAdmission(Long applicantId) {
        Applicant applicant = getApplicantEntity(applicantId);

        // Rule 1: Fee must be paid
        if (applicant.getFeeStatus() != Applicant.FeeStatus.PAID) {
            throw new FeeNotPaidException();
        }
        // Rule 2: Only one admission number per applicant
        if (admissionRepository.existsByApplicantId(applicantId)) {
            throw new AlreadyAdmittedException(applicantId);
        }

        String admissionNumber = generateAdmissionNumber(applicant);

        String currentUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        User officer = userRepository.findByUsername(currentUsername).orElse(null);

        Admission admission = Admission.builder()
                .admissionNumber(admissionNumber)
                .applicant(applicant)
                .program(applicant.getProgram())
                .confirmedBy(officer)
                .build();

        admissionRepository.save(admission);
        applicant.setStatus(Applicant.ApplicationStatus.ADMITTED);
        applicantRepository.save(applicant);
        log.info("ADMITTED: " + admissionNumber + " for applicant " + applicantId);
        return mapToResponse(applicant);
    }

    private String generateAdmissionNumber(Applicant applicant) {
        Program program     = applicant.getProgram();
        Department dept     = program.getDepartment();
        Campus campus       = dept.getCampus();
        Institution inst    = campus.getInstitution();

        String instCode     = inst.getCode() != null ? inst.getCode().toUpperCase() : "INST";
        String year         = String.valueOf(Year.now().getValue());
        String courseType   = program.getCourseType().name();
        String programCode  = program.getCode() != null ? program.getCode().toUpperCase() : "PROG";
        String quota        = applicant.getQuotaType().name();

        String prefix = instCode + "/" + year + "/" + courseType + "/" + programCode + "/" + quota + "/";
        long count = admissionRepository.countByAdmissionNumberStartingWith(prefix);
        String sequence = String.format("%04d", count + 1);
        return prefix + sequence;
        // Example: RVCE/2025/UG/CSE/KCET/0001
    }

    // ── DASHBOARD ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public DashboardDto getDashboard() {
        List<Program> programs = programRepository.findByActiveTrue();

        List<DashboardDto.ProgramSeatSummary> summaries = programs.stream()
                .map(p -> DashboardDto.ProgramSeatSummary.builder()
                        .programId(p.getId())
                        .programName(p.getName())
                        .departmentName(p.getDepartment().getName())
                        .totalIntake(p.getTotalIntake())
                        .totalAdmitted(p.getTotalAdmitted())
                        .totalRemaining(p.getTotalRemaining())
                        .kcetAvailable(p.getKcetAvailable())
                        .comedkAvailable(p.getComedkAvailable())
                        .managementAvailable(p.getManagementAvailable())
                        .build())
                .collect(Collectors.toList());

        int pendingDocs  = applicantRepository.findByDocumentStatus(Applicant.DocumentStatus.PENDING).size();
        int pendingFees  = applicantRepository.findByFeeStatus(Applicant.FeeStatus.PENDING).size();

        return DashboardDto.builder()
                .totalApplicants((int) applicantRepository.count())
                .totalAdmitted((int) applicantRepository.countByStatus(Applicant.ApplicationStatus.ADMITTED))
                .pendingDocuments(pendingDocs)
                .pendingFees(pendingFees)
                .programSummaries(summaries)
                .build();
    }

    // ── QUERIES ───────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<ApplicantDto.Response> getAllApplicants() {
        return applicantRepository.findAll().stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ApplicantDto.Response getApplicantById(Long id) {
        return mapToResponse(getApplicantEntity(id));
    }

    @Transactional(readOnly = true)
    public List<ApplicantDto.Response> getPendingDocuments() {
        return applicantRepository.findByDocumentStatus(Applicant.DocumentStatus.PENDING)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ApplicantDto.Response> getPendingFees() {
        return applicantRepository.findByFeeStatus(Applicant.FeeStatus.PENDING)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    // ── HELPERS ───────────────────────────────────────────────

    private Applicant getApplicantEntity(Long id) {
        return applicantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Applicant not found: " + id));
    }

    private ApplicantDto.Response mapToResponse(Applicant a) {
        String admissionNumber = null;
        if (a.getAdmission() != null) {
            admissionNumber = a.getAdmission().getAdmissionNumber();
        }
        return ApplicantDto.Response.builder()
                .id(a.getId())
                .firstName(a.getFirstName())
                .lastName(a.getLastName())
                .email(a.getEmail())
                .phone(a.getPhone())
                .dateOfBirth(a.getDateOfBirth())
                .gender(a.getGender())
                .address(a.getAddress())
                .category(a.getCategory())
                .qualifyingExam(a.getQualifyingExam())
                .qualifyingMarks(a.getQualifyingMarks())
                .entranceRank(a.getEntranceRank())
                .allotmentNumber(a.getAllotmentNumber())
                .entryType(a.getEntryType().name())
                .quotaType(a.getQuotaType().name())
                .admissionMode(a.getAdmissionMode().name())
                .status(a.getStatus().name())
                .documentStatus(a.getDocumentStatus().name())
                .feeStatus(a.getFeeStatus().name())
                .programId(a.getProgram().getId())
                .programName(a.getProgram().getName())
                .createdAt(a.getCreatedAt())
                .admissionNumber(admissionNumber)
                .build();
    }
}
