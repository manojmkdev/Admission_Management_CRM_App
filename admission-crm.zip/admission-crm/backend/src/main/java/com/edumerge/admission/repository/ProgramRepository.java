package com.edumerge.admission.repository;

import com.edumerge.admission.entity.Program;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProgramRepository extends JpaRepository<Program, Long> {
    List<Program> findByActiveTrue();
    List<Program> findByDepartmentIdAndActiveTrue(Long departmentId);
}
