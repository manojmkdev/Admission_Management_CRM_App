package com.edumerge.admission.repository;

import com.edumerge.admission.entity.Applicant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ApplicantRepository extends JpaRepository<Applicant, Long> {
    List<Applicant> findByDocumentStatus(Applicant.DocumentStatus documentStatus);
    List<Applicant> findByFeeStatus(Applicant.FeeStatus feeStatus);
    long countByStatus(Applicant.ApplicationStatus status);
}
