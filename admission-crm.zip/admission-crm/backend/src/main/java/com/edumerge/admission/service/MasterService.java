package com.edumerge.admission.service;

import com.edumerge.admission.dto.ProgramDto;
import com.edumerge.admission.entity.*;
import com.edumerge.admission.exception.BusinessRuleException;
import com.edumerge.admission.exception.ResourceNotFoundException;
import com.edumerge.admission.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class MasterService {

    private final InstitutionRepository institutionRepository;
    private final CampusRepository campusRepository;
    private final DepartmentRepository departmentRepository;
    private final ProgramRepository programRepository;

    public MasterService(InstitutionRepository institutionRepository,
                         CampusRepository campusRepository,
                         DepartmentRepository departmentRepository,
                         ProgramRepository programRepository) {
        this.institutionRepository = institutionRepository;
        this.campusRepository = campusRepository;
        this.departmentRepository = departmentRepository;
        this.programRepository = programRepository;
    }

    // ── INSTITUTION ───────────────────────────────────────────

    public Institution createInstitution(Institution institution) {
        if (institution.getCode() != null && institutionRepository.existsByCode(institution.getCode())) {
            throw new BusinessRuleException("Institution with code '" + institution.getCode() + "' already exists.");
        }
        return institutionRepository.save(institution);
    }

    public List<Institution> getAllInstitutions() {
        return institutionRepository.findByActiveTrue();
    }

    public Institution getInstitutionById(Long id) {
        return institutionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Institution not found: " + id));
    }

    // ── CAMPUS ────────────────────────────────────────────────

    public Campus createCampus(Campus campus, Long institutionId) {
        Institution institution = getInstitutionById(institutionId);
        campus.setInstitution(institution);
        return campusRepository.save(campus);
    }

    public List<Campus> getCampusesByInstitution(Long institutionId) {
        return campusRepository.findByInstitutionIdAndActiveTrue(institutionId);
    }

    // ── DEPARTMENT ────────────────────────────────────────────

    public Department createDepartment(Department department, Long campusId) {
        Campus campus = campusRepository.findById(campusId)
                .orElseThrow(() -> new ResourceNotFoundException("Campus not found: " + campusId));
        department.setCampus(campus);
        return departmentRepository.save(department);
    }

    public List<Department> getDepartmentsByCampus(Long campusId) {
        return departmentRepository.findByCampusIdAndActiveTrue(campusId);
    }

    // ── PROGRAM ───────────────────────────────────────────────

    public ProgramDto.Response createProgram(ProgramDto.CreateRequest request) {
        Department department = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Department not found: " + request.getDepartmentId()));

        // CRITICAL BUSINESS RULE: quota seats must sum to total intake
        int sum = request.getKcetSeats() + request.getComedkSeats() + request.getManagementSeats();
        if (sum != request.getTotalIntake()) {
            throw new BusinessRuleException(
                "Quota seats (" + sum + ") must equal total intake (" + request.getTotalIntake() + "). " +
                "KCET=" + request.getKcetSeats() + " + COMEDK=" + request.getComedkSeats() +
                " + Management=" + request.getManagementSeats() + " = " + sum);
        }

        Program program = new Program();
        program.setName(request.getName());
        program.setCode(request.getCode());
        program.setCourseType(Program.CourseType.valueOf(request.getCourseType()));
        program.setEntryType(Program.EntryType.valueOf(request.getEntryType()));
        program.setAcademicYear(request.getAcademicYear());
        program.setTotalIntake(request.getTotalIntake());
        program.setKcetSeats(request.getKcetSeats());
        program.setComedkSeats(request.getComedkSeats());
        program.setManagementSeats(request.getManagementSeats());
        program.setSupernumerarySeats(request.getSupernumerarySeats() != null ? request.getSupernumerarySeats() : 0);
        program.setKcetAllocated(0);
        program.setComedkAllocated(0);
        program.setManagementAllocated(0);
        program.setSupernumeraryAllocated(0);
        program.setDepartment(department);
        program.setActive(true);

        Program saved = programRepository.save(program);
        return mapToResponse(saved);
    }

    public List<ProgramDto.Response> getAllPrograms() {
        return programRepository.findByActiveTrue().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public ProgramDto.Response getProgramById(Long id) {
        Program p = programRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Program not found: " + id));
        return mapToResponse(p);
    }

    private ProgramDto.Response mapToResponse(Program p) {
        return ProgramDto.Response.builder()
                .id(p.getId())
                .name(p.getName())
                .code(p.getCode())
                .courseType(p.getCourseType().name())
                .entryType(p.getEntryType().name())
                .academicYear(p.getAcademicYear())
                .totalIntake(p.getTotalIntake())
                .kcetSeats(p.getKcetSeats())
                .kcetAllocated(p.getKcetAllocated())
                .kcetAvailable(p.getKcetAvailable())
                .comedkSeats(p.getComedkSeats())
                .comedkAllocated(p.getComedkAllocated())
                .comedkAvailable(p.getComedkAvailable())
                .managementSeats(p.getManagementSeats())
                .managementAllocated(p.getManagementAllocated())
                .managementAvailable(p.getManagementAvailable())
                .supernumerarySeats(p.getSupernumerarySeats())
                .supernumeraryAllocated(p.getSupernumeraryAllocated())
                .totalAdmitted(p.getTotalAdmitted())
                .totalRemaining(p.getTotalRemaining())
                .departmentId(p.getDepartment().getId())
                .departmentName(p.getDepartment().getName())
                .build();
    }
}
