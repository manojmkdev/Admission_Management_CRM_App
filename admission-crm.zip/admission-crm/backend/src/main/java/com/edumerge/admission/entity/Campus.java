package com.edumerge.admission.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "campuses")
public class Campus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 500)
    private String location;

    @Column(nullable = false)
    private boolean active = true;

    // @JsonIgnore prevents: Campus→Institution→Campus→Institution...
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "institution_id", nullable = false)
    private Institution institution;

    @JsonIgnore
    @OneToMany(mappedBy = "campus", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Department> departments;

    public Campus() {}
    public Long getId()                        { return id; }
    public void setId(Long id)                 { this.id = id; }
    public String getName()                    { return name; }
    public void setName(String n)              { this.name = n; }
    public String getLocation()                { return location; }
    public void setLocation(String l)          { this.location = l; }
    public boolean isActive()                  { return active; }
    public void setActive(boolean a)           { this.active = a; }
    public Institution getInstitution()        { return institution; }
    public void setInstitution(Institution i)  { this.institution = i; }
    public List<Department> getDepartments()           { return departments; }
    public void setDepartments(List<Department> d)     { this.departments = d; }
}
