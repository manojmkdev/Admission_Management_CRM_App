package com.edumerge.admission.exception;

/** Thrown when a business rule is violated (e.g. quota sum != intake). */
public class BusinessRuleException extends RuntimeException {
    public BusinessRuleException(String message) {
        super(message);
    }
}
