package com.edumerge.admission.exception;

/** Thrown when admission number has already been generated for this applicant. */
public class AlreadyAdmittedException extends RuntimeException {
    public AlreadyAdmittedException(Long applicantId) {
        super("Applicant ID " + applicantId + " already has an admission number generated.");
    }
}
