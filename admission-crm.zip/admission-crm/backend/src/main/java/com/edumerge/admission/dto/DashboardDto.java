package com.edumerge.admission.dto;

import java.util.List;

public class DashboardDto {
    private int totalApplicants, totalAdmitted, pendingDocuments, pendingFees;
    private List<ProgramSeatSummary> programSummaries;

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final DashboardDto d = new DashboardDto();
        public Builder totalApplicants(int v)    { d.totalApplicants = v; return this; }
        public Builder totalAdmitted(int v)      { d.totalAdmitted = v; return this; }
        public Builder pendingDocuments(int v)   { d.pendingDocuments = v; return this; }
        public Builder pendingFees(int v)        { d.pendingFees = v; return this; }
        public Builder programSummaries(List<ProgramSeatSummary> v){ d.programSummaries = v; return this; }
        public DashboardDto build()              { return d; }
    }

    public int getTotalApplicants()    { return totalApplicants; }
    public int getTotalAdmitted()      { return totalAdmitted; }
    public int getPendingDocuments()   { return pendingDocuments; }
    public int getPendingFees()        { return pendingFees; }
    public List<ProgramSeatSummary> getProgramSummaries() { return programSummaries; }

    public static class ProgramSeatSummary {
        private Long programId;
        private String programName, departmentName;
        private int totalIntake, totalAdmitted, totalRemaining,
                    kcetAvailable, comedkAvailable, managementAvailable;

        public static Builder builder() { return new Builder(); }
        public static class Builder {
            private final ProgramSeatSummary s = new ProgramSeatSummary();
            public Builder programId(Long v)           { s.programId = v; return this; }
            public Builder programName(String v)       { s.programName = v; return this; }
            public Builder departmentName(String v)    { s.departmentName = v; return this; }
            public Builder totalIntake(int v)          { s.totalIntake = v; return this; }
            public Builder totalAdmitted(int v)        { s.totalAdmitted = v; return this; }
            public Builder totalRemaining(int v)       { s.totalRemaining = v; return this; }
            public Builder kcetAvailable(int v)        { s.kcetAvailable = v; return this; }
            public Builder comedkAvailable(int v)      { s.comedkAvailable = v; return this; }
            public Builder managementAvailable(int v)  { s.managementAvailable = v; return this; }
            public ProgramSeatSummary build()          { return s; }
        }

        public Long getProgramId()         { return programId; }
        public String getProgramName()     { return programName; }
        public String getDepartmentName()  { return departmentName; }
        public int getTotalIntake()        { return totalIntake; }
        public int getTotalAdmitted()      { return totalAdmitted; }
        public int getTotalRemaining()     { return totalRemaining; }
        public int getKcetAvailable()      { return kcetAvailable; }
        public int getComedkAvailable()    { return comedkAvailable; }
        public int getManagementAvailable(){ return managementAvailable; }
    }
}
