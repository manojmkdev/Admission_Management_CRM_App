package com.edumerge.admission.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "admissions")
public class Admission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, updatable = false, length = 100)
    private String admissionNumber;

    @Column(nullable = false, updatable = false)
    private LocalDateTime confirmedAt;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "confirmed_by")
    private User confirmedBy;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "applicant_id", nullable = false, unique = true)
    private Applicant applicant;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "program_id", nullable = false)
    private Program program;

    @Column(length = 500)
    private String remarks;

    @PrePersist
    protected void onCreate() { confirmedAt = LocalDateTime.now(); }

    public Admission() {}
    public Long getId()                        { return id; }
    public void setId(Long id)                 { this.id = id; }
    public String getAdmissionNumber()         { return admissionNumber; }
    public void setAdmissionNumber(String n)   { this.admissionNumber = n; }
    public LocalDateTime getConfirmedAt()      { return confirmedAt; }
    public User getConfirmedBy()               { return confirmedBy; }
    public void setConfirmedBy(User u)         { this.confirmedBy = u; }
    public Applicant getApplicant()            { return applicant; }
    public void setApplicant(Applicant a)      { this.applicant = a; }
    public Program getProgram()                { return program; }
    public void setProgram(Program p)          { this.program = p; }
    public String getRemarks()                 { return remarks; }
    public void setRemarks(String r)           { this.remarks = r; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final Admission a = new Admission();
        public Builder admissionNumber(String v) { a.admissionNumber = v; return this; }
        public Builder applicant(Applicant v)    { a.applicant = v; return this; }
        public Builder program(Program v)        { a.program = v; return this; }
        public Builder confirmedBy(User v)       { a.confirmedBy = v; return this; }
        public Builder remarks(String v)         { a.remarks = v; return this; }
        public Admission build()                 { return a; }
    }
}
