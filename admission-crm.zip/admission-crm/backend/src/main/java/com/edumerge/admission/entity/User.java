package com.edumerge.admission.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String username;

    // Always hide password from JSON responses
    @JsonIgnore
    @Column(nullable = false)
    private String password;

    @Column(nullable = false, length = 100)
    private String fullName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private Role role;

    @Column(nullable = false)
    private boolean active = true;

    public User() {}
    public Long getId()              { return id; }
    public void setId(Long id)       { this.id = id; }
    public String getUsername()      { return username; }
    public void setUsername(String u){ this.username = u; }
    public String getPassword()      { return password; }
    public void setPassword(String p){ this.password = p; }
    public String getFullName()      { return fullName; }
    public void setFullName(String f){ this.fullName = f; }
    public Role getRole()            { return role; }
    public void setRole(Role r)      { this.role = r; }
    public boolean isActive()        { return active; }
    public void setActive(boolean a) { this.active = a; }

    public static Builder builder()  { return new Builder(); }
    public static class Builder {
        private final User user = new User();
        public Builder username(String u)  { user.username = u; return this; }
        public Builder password(String p)  { user.password = p; return this; }
        public Builder fullName(String f)  { user.fullName = f; return this; }
        public Builder role(Role r)        { user.role = r; return this; }
        public Builder active(boolean a)   { user.active = a; return this; }
        public User build()                { return user; }
    }

    public enum Role { ADMIN, ADMISSION_OFFICER, MANAGEMENT }
}
