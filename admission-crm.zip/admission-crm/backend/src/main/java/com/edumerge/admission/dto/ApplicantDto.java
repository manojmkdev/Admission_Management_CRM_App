package com.edumerge.admission.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ApplicantDto {

    public static class CreateRequest {
        private String firstName, lastName, email, phone, gender, address,
                       category, qualifyingExam, entranceRank, allotmentNumber,
                       entryType, quotaType, admissionMode;
        private LocalDate dateOfBirth;
        private Double qualifyingMarks;
        private Long programId;

        public String getFirstName()         { return firstName; }
        public void setFirstName(String v)   { this.firstName = v; }
        public String getLastName()          { return lastName; }
        public void setLastName(String v)    { this.lastName = v; }
        public String getEmail()             { return email; }
        public void setEmail(String v)       { this.email = v; }
        public String getPhone()             { return phone; }
        public void setPhone(String v)       { this.phone = v; }
        public String getGender()            { return gender; }
        public void setGender(String v)      { this.gender = v; }
        public String getAddress()           { return address; }
        public void setAddress(String v)     { this.address = v; }
        public String getCategory()          { return category; }
        public void setCategory(String v)    { this.category = v; }
        public String getQualifyingExam()    { return qualifyingExam; }
        public void setQualifyingExam(String v){ this.qualifyingExam = v; }
        public String getEntranceRank()      { return entranceRank; }
        public void setEntranceRank(String v){ this.entranceRank = v; }
        public String getAllotmentNumber()    { return allotmentNumber; }
        public void setAllotmentNumber(String v){ this.allotmentNumber = v; }
        public String getEntryType()         { return entryType; }
        public void setEntryType(String v)   { this.entryType = v; }
        public String getQuotaType()         { return quotaType; }
        public void setQuotaType(String v)   { this.quotaType = v; }
        public String getAdmissionMode()     { return admissionMode; }
        public void setAdmissionMode(String v){ this.admissionMode = v; }
        public LocalDate getDateOfBirth()    { return dateOfBirth; }
        public void setDateOfBirth(LocalDate v){ this.dateOfBirth = v; }
        public Double getQualifyingMarks()   { return qualifyingMarks; }
        public void setQualifyingMarks(Double v){ this.qualifyingMarks = v; }
        public Long getProgramId()           { return programId; }
        public void setProgramId(Long v)     { this.programId = v; }
    }

    public static class Response {
        private Long id;
        private String firstName, lastName, email, phone, gender, address,
                       category, qualifyingExam, entranceRank, allotmentNumber,
                       entryType, quotaType, admissionMode,
                       status, documentStatus, feeStatus, programName, admissionNumber;
        private LocalDate dateOfBirth;
        private Double qualifyingMarks;
        private Long programId;
        private LocalDateTime createdAt;

        public static Builder builder() { return new Builder(); }
        public static class Builder {
            private final Response r = new Response();
            public Builder id(Long v)               { r.id = v; return this; }
            public Builder firstName(String v)      { r.firstName = v; return this; }
            public Builder lastName(String v)       { r.lastName = v; return this; }
            public Builder email(String v)          { r.email = v; return this; }
            public Builder phone(String v)          { r.phone = v; return this; }
            public Builder gender(String v)         { r.gender = v; return this; }
            public Builder address(String v)        { r.address = v; return this; }
            public Builder category(String v)       { r.category = v; return this; }
            public Builder qualifyingExam(String v) { r.qualifyingExam = v; return this; }
            public Builder entranceRank(String v)   { r.entranceRank = v; return this; }
            public Builder allotmentNumber(String v){ r.allotmentNumber = v; return this; }
            public Builder entryType(String v)      { r.entryType = v; return this; }
            public Builder quotaType(String v)      { r.quotaType = v; return this; }
            public Builder admissionMode(String v)  { r.admissionMode = v; return this; }
            public Builder status(String v)         { r.status = v; return this; }
            public Builder documentStatus(String v) { r.documentStatus = v; return this; }
            public Builder feeStatus(String v)      { r.feeStatus = v; return this; }
            public Builder programName(String v)    { r.programName = v; return this; }
            public Builder admissionNumber(String v){ r.admissionNumber = v; return this; }
            public Builder dateOfBirth(LocalDate v) { r.dateOfBirth = v; return this; }
            public Builder qualifyingMarks(Double v){ r.qualifyingMarks = v; return this; }
            public Builder programId(Long v)        { r.programId = v; return this; }
            public Builder createdAt(LocalDateTime v){ r.createdAt = v; return this; }
            public Response build()                 { return r; }
        }

        public Long getId()              { return id; }
        public String getFirstName()     { return firstName; }
        public String getLastName()      { return lastName; }
        public String getEmail()         { return email; }
        public String getPhone()         { return phone; }
        public String getGender()        { return gender; }
        public String getAddress()       { return address; }
        public String getCategory()      { return category; }
        public String getQualifyingExam(){ return qualifyingExam; }
        public String getEntranceRank()  { return entranceRank; }
        public String getAllotmentNumber(){ return allotmentNumber; }
        public String getEntryType()     { return entryType; }
        public String getQuotaType()     { return quotaType; }
        public String getAdmissionMode() { return admissionMode; }
        public String getStatus()        { return status; }
        public String getDocumentStatus(){ return documentStatus; }
        public String getFeeStatus()     { return feeStatus; }
        public String getProgramName()   { return programName; }
        public String getAdmissionNumber(){ return admissionNumber; }
        public LocalDate getDateOfBirth(){ return dateOfBirth; }
        public Double getQualifyingMarks(){ return qualifyingMarks; }
        public Long getProgramId()       { return programId; }
        public LocalDateTime getCreatedAt(){ return createdAt; }
    }

    public static class UpdateDocumentStatus {
        private String documentStatus;
        public String getDocumentStatus()         { return documentStatus; }
        public void setDocumentStatus(String v)   { this.documentStatus = v; }
    }

    public static class UpdateFeeStatus {
        private String feeStatus;
        public String getFeeStatus()              { return feeStatus; }
        public void setFeeStatus(String v)        { this.feeStatus = v; }
    }
}
