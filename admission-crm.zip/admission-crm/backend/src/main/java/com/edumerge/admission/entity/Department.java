package com.edumerge.admission.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "departments")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 20)
    private String code;

    @Column(length = 500)
    private String description;

    @Column(nullable = false)
    private boolean active = true;

    // @JsonIgnore prevents: Department→Campus→Department→Campus...
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "campus_id", nullable = false)
    private Campus campus;

    @JsonIgnore
    @OneToMany(mappedBy = "department", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Program> programs;

    public Department() {}
    public Long getId()                      { return id; }
    public void setId(Long id)               { this.id = id; }
    public String getName()                  { return name; }
    public void setName(String n)            { this.name = n; }
    public String getCode()                  { return code; }
    public void setCode(String c)            { this.code = c; }
    public String getDescription()           { return description; }
    public void setDescription(String d)     { this.description = d; }
    public boolean isActive()                { return active; }
    public void setActive(boolean a)         { this.active = a; }
    public Campus getCampus()                { return campus; }
    public void setCampus(Campus c)          { this.campus = c; }
    public List<Program> getPrograms()       { return programs; }
    public void setPrograms(List<Program> p) { this.programs = p; }
}
