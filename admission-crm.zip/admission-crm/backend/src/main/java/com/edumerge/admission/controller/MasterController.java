package com.edumerge.admission.controller;

import com.edumerge.admission.dto.ApiResponse;
import com.edumerge.admission.dto.ProgramDto;
import com.edumerge.admission.entity.*;
import com.edumerge.admission.service.MasterService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class MasterController {

    private final MasterService masterService;

    public MasterController(MasterService masterService) {
        this.masterService = masterService;
    }

    // ── INSTITUTIONS ──────────────────────────────────────────

    @PostMapping("/institutions")
    public ResponseEntity<ApiResponse<Institution>> createInstitution(@RequestBody Institution institution) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Institution created", masterService.createInstitution(institution)));
    }

    @GetMapping("/institutions")
    public ResponseEntity<ApiResponse<List<Institution>>> getAllInstitutions() {
        return ResponseEntity.ok(ApiResponse.success("OK", masterService.getAllInstitutions()));
    }

    @GetMapping("/institutions/{id}")
    public ResponseEntity<ApiResponse<Institution>> getInstitution(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("OK", masterService.getInstitutionById(id)));
    }

    // ── CAMPUSES ──────────────────────────────────────────────

    @PostMapping("/campuses")
    public ResponseEntity<ApiResponse<Campus>> createCampus(@RequestBody Campus campus,
                                                             @RequestParam Long institutionId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Campus created", masterService.createCampus(campus, institutionId)));
    }

    @GetMapping("/campuses")
    public ResponseEntity<ApiResponse<List<Campus>>> getCampuses(@RequestParam Long institutionId) {
        return ResponseEntity.ok(ApiResponse.success("OK", masterService.getCampusesByInstitution(institutionId)));
    }

    // ── DEPARTMENTS ───────────────────────────────────────────

    @PostMapping("/departments")
    public ResponseEntity<ApiResponse<Department>> createDepartment(@RequestBody Department department,
                                                                     @RequestParam Long campusId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Department created", masterService.createDepartment(department, campusId)));
    }

    @GetMapping("/departments")
    public ResponseEntity<ApiResponse<List<Department>>> getDepartments(@RequestParam Long campusId) {
        return ResponseEntity.ok(ApiResponse.success("OK", masterService.getDepartmentsByCampus(campusId)));
    }

    // ── PROGRAMS ──────────────────────────────────────────────

    @PostMapping("/programs")
    public ResponseEntity<ApiResponse<ProgramDto.Response>> createProgram(@RequestBody ProgramDto.CreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Program created", masterService.createProgram(request)));
    }

    @GetMapping("/programs")
    public ResponseEntity<ApiResponse<List<ProgramDto.Response>>> getAllPrograms() {
        return ResponseEntity.ok(ApiResponse.success("OK", masterService.getAllPrograms()));
    }

    @GetMapping("/programs/{id}")
    public ResponseEntity<ApiResponse<ProgramDto.Response>> getProgram(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("OK", masterService.getProgramById(id)));
    }
}
