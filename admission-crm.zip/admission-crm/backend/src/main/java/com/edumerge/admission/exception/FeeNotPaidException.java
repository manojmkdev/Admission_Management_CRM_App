package com.edumerge.admission.exception;

/** Thrown when trying to confirm admission but fee is not yet paid. */
public class FeeNotPaidException extends RuntimeException {
    public FeeNotPaidException() {
        super("Admission can only be confirmed after fee is marked as PAID.");
    }
}
