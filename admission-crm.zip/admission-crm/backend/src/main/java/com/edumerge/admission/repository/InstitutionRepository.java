package com.edumerge.admission.repository;

import com.edumerge.admission.entity.Institution;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface InstitutionRepository extends JpaRepository<Institution, Long> {
    List<Institution> findByActiveTrue();
    boolean existsByCode(String code);
}
