package com.edumerge.admission.repository;

import com.edumerge.admission.entity.Campus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CampusRepository extends JpaRepository<Campus, Long> {
    List<Campus> findByInstitutionIdAndActiveTrue(Long institutionId);
}
